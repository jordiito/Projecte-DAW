<div class="rg-container">
	<main>
		<div class="content">
			<div class="grid">
				<div class="winfo">

					<h1 class="title"><?php echo $titol;?></h1>
					<p class="description"><?php echo $missatge;?></p>

				</div>

			</div>
		</div>
	</main>
</div>