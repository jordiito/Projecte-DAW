
<footer>
        <div class="container">
            <div class="footersec">
                <ul>
                    <li><img class="icono" src="img/blog.png" alt=""><a href="">Blog</a></li>
                    <li><img class="icono" src="img/youtube.png" alt=""><a href="">YouTube</a></li>
                    <li><img class="icono" src="img/twitter.png" alt=""><a href="">Twitter</a></li>
                    <li><img class="icono" src="img/instagram.png" alt=""><a href="">Instagram</a></li>
                    <li><img class="icono" src="img/facebook.png" alt=""><a href="">Facebook</a></li>
                </ul>
            </div>
            <div class="footersec">
                <p>Contacte</p>
                <ul>
                    <li><a href="">Formulari de contacte</a></li>
                    <li><a href="">Centre de suport</a></li>
                </ul>
            </div>
            <div class="footersec">
                <p>Sobre nosaltres</p>
                <ul>
                    <li><a href="">Qui som?</a></li>
                    <li><a href="">Treballa amb nosaltres</a></li>
                </ul>
            </div>
            <div class="footersec">
                <p>Privacitat</p>
                <ul>
                    <li><a href="">Política de privacitat</a></li>
                    <li><a href="">Política de cookies</a></li>
                    <li><a href="">Política de devolucions</a></li>
                </ul>
            </div>
        </div>
        <script src='js/script.js'></script>
        
    </footer>
    
</body>
</html>