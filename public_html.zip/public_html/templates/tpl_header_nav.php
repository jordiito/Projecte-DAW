
<nav>
	<div id="logo" class="fl">
		<a href="index.php"><img src="img/logo.png"></a>
	</div>
	<button id="catmenu">
		<img id="caticon" src="img/menu.png"></img>
	</button>
	<div id="mainmenu" class="fr">
		<ul id="menu">
			<li><a href="index.php" class="active">Home</a></li>
			<br class="salt">
			<li><a href="index.php?url=ContacteController/show">Contacte</a></li>
			<br class="salt">
			<li><a href="index.php">Sobre nosaltres</a></li>
		</ul>
		<div id="user">
			<a href="index.php?url=UsuarioController/logIn" class="icon"> <img id="carticon" src="img/usuario.png"></img>
			</a>
		</div>
		<div id="carreto">
			<a id="cart" class="icon"> <img id="carticon" src="img/agregar-carrito.png"></img>
			</a>
		</div>
	</div>
</nav>