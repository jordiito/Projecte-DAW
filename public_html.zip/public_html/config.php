<?php
//Dades de configuració per accés a base de dades
$dbServidor ="localhost";
$dbUsernamePerConsultes = "jordi";
$dbUsernamePerAccions = "jordi";
$dbPassword = "thos";
$dbBaseDeDades = "botiga";