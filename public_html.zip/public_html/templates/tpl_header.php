<header class="one">
<?php
include "templates/tpl_header_nav.php";
include "templates/tpl_header_carrito.php";
?>
</header>