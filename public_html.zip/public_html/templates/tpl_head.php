<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
<title>Botiga</title>
<link rel="stylesheet" href="css/style.css"/>
<script type="text/javascript" src="js/index.js"></script>

</head>
<body>	